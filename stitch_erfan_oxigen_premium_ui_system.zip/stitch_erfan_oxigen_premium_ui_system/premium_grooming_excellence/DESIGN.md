---
name: Premium Grooming Excellence
colors:
  surface: '#101417'
  surface-dim: '#101417'
  surface-bright: '#363a3d'
  surface-container-lowest: '#0b0f11'
  surface-container-low: '#191c1f'
  surface-container: '#1d2023'
  surface-container-high: '#272a2d'
  surface-container-highest: '#323538'
  on-surface: '#e0e2e6'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e0e2e6'
  inverse-on-surface: '#2d3134'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#c6c6cc'
  on-secondary: '#2f3035'
  secondary-container: '#47494e'
  on-secondary-container: '#b7b8bd'
  tertiary: '#ccced7'
  on-tertiary: '#2d3038'
  tertiary-container: '#b0b2bc'
  on-tertiary-container: '#42454d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e2e2e8'
  secondary-fixed-dim: '#c6c6cc'
  on-secondary-fixed: '#1a1c20'
  on-secondary-fixed-variant: '#45474b'
  tertiary-fixed: '#e0e2ec'
  tertiary-fixed-dim: '#c4c6d0'
  on-tertiary-fixed: '#191c22'
  on-tertiary-fixed-variant: '#44474e'
  background: '#101417'
  on-background: '#e0e2e6'
  surface-variant: '#323538'
typography:
  display-lg:
    fontFamily: Vazirmatn
    fontSize: 34px
    fontWeight: '800'
    lineHeight: 48px
  headline-lg:
    fontFamily: Vazirmatn
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Vazirmatn
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Vazirmatn
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Vazirmatn
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Vazirmatn
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Vazirmatn
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 20px
  gutter: 16px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 40px
---

## Brand & Style

The design system embodies ultra-luxury masculine grooming, focusing on a cinematic and prestigious atmosphere. It is tailored for high-end clientele who value precision, heritage, and exclusivity.

### Design Style: Cinematic Noir
The aesthetic leverages **Glassmorphism** and **High-Contrast Bold** elements to create a sense of depth and prestige.
- **Atmosphere:** Moody, dark, and intimate, mimicking the lighting of a high-end studio.
- **Visual Depth:** Semi-transparent surfaces with high-quality background blurs are used to layer information without breaking the immersive dark environment.
- **Accents:** Warm metallic gold is used sparingly but impactfully to denote value, action, and premium status.
- **Directionality:** Full support for Right-to-Left (RTL) layouts, ensuring natural Persian reading flow.

## Colors

The palette is strictly controlled to maintain a high-end, "Noir" aesthetic.

- **Primary (Metallic Gold):** Used for primary CTAs, active states, and critical branding elements. It should feel radiant against the dark background.
- **Secondary (Deep Navy/Charcoal):** Used for card backgrounds and secondary surfaces to provide subtle contrast against the true black background.
- **Neutral (Light Gray/White):** Reserved for high-readability text and subtle borders.
- **Gradients:** Use linear gradients for primary buttons (e.g., `#D4AF37` to `#B8860B`) to simulate a metallic sheen.

## Typography

The system utilizes **Vazirmatn** (or similar high-legibility Persian typefaces) to ensure the script looks modern and sophisticated. 

- **Alignment:** All text is right-aligned by default.
- **Weight Strategy:** Headlines use heavy weights (Bold/Black) to command attention, while body text remains regular for readability against dark backgrounds.
- **Contrast:** High contrast is maintained for labels and body text using `#E5E7EB`. Avoid pure white for large blocks of text to reduce eye strain in dark mode.

## Layout & Spacing

The layout is optimized for a premium mobile experience using a **Fluid Grid** model.

- **Margins:** A consistent 20px safe area on the horizontal edges (Right/Left).
- **Rhythm:** An 8px base unit drives all spacing decisions.
- **Mobile Reflow:** For cards and list items, the layout uses a single-column stack or 2-column grid depending on content density (e.g., gallery items).
- **Visual Breathing Room:** Generous vertical padding (`stack-lg`) between major sections to maintain a clean, uncrowded feel.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layering** and **Glassmorphism**, rather than traditional heavy shadows.

- **Surface 0:** Pure Black (`#0A0A0A`) - The foundation.
- **Surface 1:** Deep Navy (`#121418`) - For cards and containers.
- **Surface 2:** Semi-transparent Glass (`rgba(28, 31, 38, 0.7)`) - For floating navbars and overlays, with a 20px background blur.
- **Inner Glows:** Interactive elements like primary buttons feature a soft gold outer glow (`spread: 10px, opacity: 0.2`) to simulate cinematic lighting.
- **Outlines:** Use 1px low-opacity gold borders (`rgba(212, 175, 55, 0.3)`) for input fields and secondary buttons to define shape without adding visual weight.

## Shapes

The shape language is **Rounded**, balancing masculinity with modern elegance.

- **Standard Elements:** 0.5rem (8px) for buttons, small cards, and inputs.
- **Large Containers:** 1rem (16px) for main content cards and modal sheets.
- **Profile/Avatars:** Circles are used for user imagery to create a soft focal point in the structured layout.

## Components

### Buttons
- **Primary:** Gold metallic gradient background with black text. Features a subtle gold shadow.
- **Secondary:** Transparent background with a 1px gold border and gold text.
- **Icon Buttons:** Circular or rounded-square surfaces with thin-line gold icons.

### Inputs
- **Text Fields:** Dark secondary background (`#121418`) with a subtle border. Icons and labels are right-aligned.
- **Selectors:** Use a glassmorphic bottom sheet for selections.

### Cards
- **Service Cards:** Feature a background image with a dark gradient overlay at the bottom to ensure white text legibility.
- **Manager Label:** Always labeled as "مدیر" in a small, high-contrast gold badge.

### Navigation
- **Bottom Bar:** Glassmorphic container with 70% opacity and background blur. Active icons are gold; inactive icons are light gray.

### Iconography
- **Style:** Thin-line (2pt stroke) icons. Avoid filled or heavy icons to maintain a refined look. Icons should be colored gold for primary actions or white for navigation.